/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            quickview :'Product_Quickview/js/quickview',
            delete :  'Product_Quickview/js/delete',
            quickaddtocart : 'Product_Quickview/js/quickaddtocart'
        }
    }
};
