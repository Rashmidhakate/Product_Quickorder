/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
    'jquery/ui',
], function ($) {
    'use strict';
    //creating jquery widget
    $.widget('mage.quickview', {
        _create: function() {
            console.log('hey, srjs is loaded!')
            //bind click event of elem id
            var i=1;
            this.element.on('click', function(e){
                e.preventDefault();
                var newrow = $("#product_row").clone();
                $(newrow).attr("id","newrow"+i);
                var child = newrow.children();
                child.find('button').each(function(elem) {
                    if($(this).attr('id') == 'delete'){
                        $(this).attr("id","delete"+i);
                    }
                });
                $(newrow).insertAfter($("#product_row"));
                i++;
            });
        }
    });

    return $.mage.quickview;
});
