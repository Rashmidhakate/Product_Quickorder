/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
    'jquery/ui',
], function ($) {
    'use strict';
    //creating jquery widget
    $.widget('mage.delete', {
        _create: function() {
            console.log('hey, srjs is loaded!')
    //         //bind click event of elem id
    //         this.element.on('click', function(e){
    //         	e.preventDefault();
				// var newrow = $("#product_row").clone();
				// $(newrow).attr("id","newrow");
				// $(newrow).insertAfter($("#product_row"));
    //         });
        }
 
    });

    return $.mage.delete;
});
