<?php
namespace Product\Quickview\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
 
class Product extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $resultJsonFactory;
    protected $collectionFactory;

    public function __construct(
        Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $_productCollectionFactory,
        \Magento\Framework\Controller\ResultFactory $resultFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_productCollectionFactory = $_productCollectionFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        $searchValue = $this->getRequest()->getPost('search_text');
        $result = $this->resultJsonFactory->create();
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect(array('sku','name'));
        $collection->addAttributeToFilter(
            array(
                array('attribute'=> 'sku','like' => '%'.$searchValue.'%'),
                array('attribute'=> 'name','like' => '%'.$searchValue.'%','left'),
            ));
        //echo $collection->getSelect()->__toString();
        //die();
        //$collection->addAttributeToFilter('sku', $searchValue);
        // echo "<pre>";
        // print_r($collection->getData());
        // die();
        $resultJson->setData($collection->getData());
        return $resultJson;
        // $resultPage = $this->_resultPageFactory->create();
        // return $resultPage;
    }
}