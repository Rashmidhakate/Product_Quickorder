<?php 

namespace Product\Quickview\Block;

use Magento\Framework\View\Element\Template;

class Quickview extends Template{

	protected $_storeManager;

	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Store\Model\StoreManagerInterface $storeManager
		)
	{
		$this->_storeManager = $storeManager;
		parent::__construct($context);
	}

	public function getAddToCartUrl()
	{
		return $this->getUrl("quickview/*/addtocart");
	}

	public function getBaseUrl(){
		return $this->_storeManager->getStore()->getBaseUrl();
	}
}